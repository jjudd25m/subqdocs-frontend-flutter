class FilterListingModel {
    String filterName ;
    String filterValue;


    FilterListingModel({required this.filterName , required this.filterValue});

}

