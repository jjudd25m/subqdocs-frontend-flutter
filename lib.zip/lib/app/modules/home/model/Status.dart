class StatusModel {
  String? status;

  StatusModel({this.status});
}
