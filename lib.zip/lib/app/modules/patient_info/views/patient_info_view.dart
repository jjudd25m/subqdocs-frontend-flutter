import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:subqdocs/app/modules/patient_info/views/confirm_finalize_dialog.dart';
import 'package:subqdocs/app/modules/patient_info/views/doctor_view.dart';
import 'package:subqdocs/app/modules/patient_info/views/full_note_view.dart';
import 'package:subqdocs/app/modules/patient_info/views/patient_view.dart';
import 'package:subqdocs/app/modules/patient_info/views/visit_data_view.dart';
import 'package:subqdocs/widgets/base_screen.dart';

import '../../../../utils/app_colors.dart';
import '../../../../utils/app_fonts.dart';
import '../../../../utils/imagepath.dart';
import '../../../../widget/appbar.dart';
import '../../../../widget/base_image_view.dart';
import '../../../../widget/bredcums.dart';
import '../../../../widget/custom_animated_button.dart';
import '../../../routes/app_pages.dart';
import '../controllers/patient_info_controller.dart';
import 'full_transcript_view.dart';

class PatientInfoView extends StatefulWidget {
  const PatientInfoView({super.key});

  @override
  State<PatientInfoView> createState() => _PatientInfoViewState();
}

class _PatientInfoViewState extends State<PatientInfoView> {
  PatientInfoController controller = Get.find<PatientInfoController>(tag: Get.arguments["unique_tag"]);

  final GlobalKey<ScaffoldState> _key = GlobalKey();

  String formatDateTime({required String firstDate, required String secondDate}) {
    if (firstDate != "" && secondDate != "") {
      // Parse the first and second arguments to DateTime objects
      DateTime firstDateTime = DateTime.parse(firstDate);
      DateTime secondDateTime = DateTime.parse(secondDate);

      // Format the first date (for month/day/year format)
      String formattedDate = DateFormat('MM/dd/yyyy').format(firstDateTime);

      // Format the second time (for hours and minutes with am/pm)
      String formattedTime = DateFormat('h:mm a').format(secondDateTime.toLocal());

      // Return the formatted string in the desired format
      return '$formattedDate $formattedTime';
    } else {
      return "";
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BaseScreen(
      onPopCallBack: () {
        if (controller.globalController.getKeyByValue(controller.globalController.breadcrumbHistory.last) == Routes.PATIENT_INFO) {
          controller.globalController.popRoute();
        }
      },
      onDrawerChanged: (status) {
        print("drawer status is :- ${status}");

        if (status) {
          controller.closeAllProcedureDiagnosisPopover();
        }
      },
      resizeToAvoidBottomInset: true,
      onItemSelected: (index) async {
        if (index == 0) {
          final result = await Get.toNamed(Routes.ADD_PATIENT);
          _key.currentState!.closeDrawer();
        } else if (index == 1) {
          Get.offNamed(Routes.HOME, arguments: {"tabIndex": 1});
          _key.currentState!.closeDrawer();
        } else if (index == 2) {
          Get.offNamed(Routes.HOME, arguments: {"tabIndex": 2});
          _key.currentState!.closeDrawer();
        } else if (index == 3) {
          Get.offNamed(Routes.HOME, arguments: {"tabIndex": 0});
          _key.currentState!.closeDrawer();
        } else if (index == 4) {
          _key.currentState!.closeDrawer();
          final result = await Get.toNamed(Routes.PERSONAL_SETTING);
        }
      },
      body: SafeArea(
        child: GestureDetector(
          onTap: () {
            print("fdgrfge");

            controller.closeAllProcedureDiagnosisPopover();
            // FocusScope.of(context).unfocus();

            controller.resetImpressionAndPlanList();
          },
          child: Obx(() {
            return Column(
              children: [
                if (!controller.isKeyboardVisible.value) ...[CustomAppBar(drawerkey: _key)],
                Expanded(
                  child: Container(
                    color: AppColors.ScreenBackGround1,
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: RefreshIndicator(
                      onRefresh: controller.onRefresh, // Trigger the refresh
                      child: SingleChildScrollView(
                        controller: controller.scrollController,
                        physics: AlwaysScrollableScrollPhysics(),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 10),
                            Obx(() {
                              return BreadcrumbWidget(
                                breadcrumbHistory: controller.globalController.breadcrumbHistory.value,
                                onBack: (breadcrumb) {
                                  controller.globalController.popUntilRoute(breadcrumb);
                                  while (Get.currentRoute != controller.globalController.getKeyByValue(breadcrumb)) {
                                    Get.back(); // Pop the current screen
                                  }
                                },
                              );
                            }),
                            const SizedBox(height: 10),
                            Column(
                              children: <Widget>[
                                Container(width: double.infinity, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8)), child: Padding(padding: const EdgeInsets.all(14), child: Text("Patient Visit Record", style: AppFonts.regular(17, AppColors.textBlack)))),
                                const SizedBox(height: 15.0),
                                Obx(() {
                                  return Theme(
                                    data: ThemeData(
                                      splashColor: Colors.transparent,
                                      // Remove splash color
                                      highlightColor: Colors.transparent, // Remove highlight color
                                    ),
                                    child: ExpansionTile(
                                      initiallyExpanded: true,
                                      onExpansionChanged: (value) {
                                        controller.closeAllProcedureDiagnosisPopover();
                                      },
                                      collapsedShape: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(8)),
                                      shape: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(8)),
                                      backgroundColor: AppColors.backgroundWhite,
                                      collapsedBackgroundColor: AppColors.backgroundWhite,
                                      title: Padding(
                                        padding: const EdgeInsets.symmetric(vertical: 5),
                                        child: Row(
                                          children: [
                                            InkWell(
                                              onTap: () {
                                                Get.until((route) => Get.currentRoute == Routes.HOME);
                                                controller.globalController.breadcrumbHistory.clear();
                                                controller.globalController.addRoute(Routes.HOME);

                                                // Get.back();
                                              },
                                              child: Container(color: AppColors.white, padding: const EdgeInsets.only(left: 10.0, top: 20.0, bottom: 20.0, right: 20.0), child: SvgPicture.asset(ImagePath.logo_back, height: 20, width: 20)),
                                            ),
                                            ClipRRect(
                                              borderRadius: BorderRadius.circular(30),
                                              child: BaseImageView(
                                                imageUrl: controller.patientData.value?.responseData?.profileImage ?? "",
                                                height: 60,
                                                width: 60,
                                                nameLetters: "${controller.patientData.value?.responseData?.patientFirstName ?? ""} ${controller.patientData.value?.responseData?.patientLastName ?? ""}",
                                                fontSize: 14,
                                              ),
                                            ),
                                            const SizedBox(width: 10),
                                            Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(textAlign: TextAlign.center, "${controller.patientData.value?.responseData?.patientFirstName ?? ""} ${controller.patientData.value?.responseData?.patientLastName ?? ""} ", style: AppFonts.medium(16, AppColors.textBlack)),
                                                const SizedBox(width: 15),
                                                Text(textAlign: TextAlign.center, controller.patientData.value?.responseData?.patientId ?? "", style: AppFonts.regular(11, AppColors.textGrey)),
                                              ],
                                            ),
                                            const Spacer(),
                                          ],
                                        ),
                                      ),
                                      children: <Widget>[
                                        Container(width: double.infinity, height: 1, color: AppColors.appbarBorder),
                                        const SizedBox(height: 10),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(horizontal: 20),
                                          child: Row(
                                            children: [
                                              Column(
                                                children: [
                                                  Text(textAlign: TextAlign.center, "Age", style: AppFonts.regular(12, AppColors.textBlack)),
                                                  const SizedBox(height: 6),
                                                  Text(textAlign: TextAlign.center, (controller.patientData.value?.responseData?.age.toString() ?? "") == "null" ? "N/A" : controller.patientData.value?.responseData?.age.toString() ?? "", style: AppFonts.regular(14, AppColors.textGrey)),
                                                ],
                                              ),
                                              const Spacer(),
                                              Column(
                                                children: [
                                                  Text(textAlign: TextAlign.center, "Gender", style: AppFonts.regular(12, AppColors.textBlack)),
                                                  const SizedBox(height: 6),
                                                  Text(textAlign: TextAlign.center, controller.patientData.value?.responseData?.gender ?? "N/A", style: AppFonts.regular(14, AppColors.textGrey)),
                                                ],
                                              ),
                                              const Spacer(),
                                              Column(
                                                children: [
                                                  Text(textAlign: TextAlign.center, "Visit Date & Time", style: AppFonts.regular(12, AppColors.textBlack)),
                                                  const SizedBox(height: 6),
                                                  Text(textAlign: TextAlign.center, formatDateTime(firstDate: controller.patientData.value?.responseData?.visitDate ?? "-", secondDate: controller.patientData.value?.responseData?.visitTime ?? ""), style: AppFonts.regular(14, AppColors.textGrey)),
                                                ],
                                              ),
                                              const Spacer(),
                                              Column(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Text(textAlign: TextAlign.center, "Medical Assistant", style: AppFonts.regular(12, AppColors.textBlack)),
                                                  const SizedBox(height: 6),
                                                  Text(textAlign: TextAlign.center, controller.medicationValue.value ?? "N/A", style: AppFonts.regular(14, AppColors.textGrey)),

                                                  // GestureDetector(
                                                  //   onLongPress: () {
                                                  //     CustomToastification().showToast("test");
                                                  //   },
                                                  //   child: PopupMenuButton<String>(
                                                  //     offset: const Offset(0, 8),
                                                  //     shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                                                  //     color: AppColors.white,
                                                  //     position: PopupMenuPosition.under,
                                                  //     padding: EdgeInsetsDirectional.zero,
                                                  //     menuPadding: EdgeInsetsDirectional.zero,
                                                  //     onSelected: (value) {},
                                                  //     style: const ButtonStyle(
                                                  //       padding: WidgetStatePropertyAll(EdgeInsetsDirectional.zero),
                                                  //       tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                                  //       maximumSize: WidgetStatePropertyAll(Size.zero),
                                                  //       visualDensity: VisualDensity(horizontal: 0, vertical: 0),
                                                  //     ),
                                                  //     itemBuilder:
                                                  //         (context) => [
                                                  //           PopupMenuItem(
                                                  //             padding: EdgeInsets.zero,
                                                  //             onTap: () async {},
                                                  //             value: "",
                                                  //             child: Padding(
                                                  //               padding: const EdgeInsets.all(0),
                                                  //               child: SizedBox(
                                                  //                 width: 160,
                                                  //                 child: DropDownWithSearchPopup(
                                                  //                   key: UniqueKey(),
                                                  //                   onChanged: (value, index, selectedId, name) {
                                                  //                     print("hello");
                                                  //
                                                  //                     controller.medicationValue.value = name;
                                                  //                     Get.back();
                                                  //                     controller.updateMedicalView(selectedId);
                                                  //                   },
                                                  //                   list: controller.globalController.selectedMedicalModel.value,
                                                  //                   receiveParam: (String value) {},
                                                  //                   selectedId: 1,
                                                  //                 ),
                                                  //               ),
                                                  //             ),
                                                  //           ),
                                                  //         ],
                                                  //     child: SizedBox(
                                                  //       width: 170,
                                                  //       child: ContainerDropdownViewPopUp(
                                                  //         receiveParam: (isExpand) {
                                                  //           // isExpandedMedicalAssistant.value = isExpand;
                                                  //         },
                                                  //         name: controller.medicationValue.value,
                                                  //       ),
                                                  //     ),
                                                  //   ),
                                                  // ),
                                                ],
                                              ),

                                              // Column(
                                              //   crossAxisAlignment: CrossAxisAlignment.start,
                                              //   children: [
                                              //     Text(textAlign: TextAlign.start, "Medical Assistant", style: AppFonts.regular(12, AppColors.textBlack)),
                                              //     const SizedBox(height: 6),
                                              //     GestureDetector(
                                              //       onLongPress: () {
                                              //         CustomToastification().showToast("test");
                                              //       },
                                              //       child: PopupMenuButton<String>(
                                              //         offset: const Offset(0, 8),
                                              //         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                                              //         color: AppColors.white,
                                              //         position: PopupMenuPosition.under,
                                              //         padding: EdgeInsetsDirectional.zero,
                                              //         menuPadding: EdgeInsetsDirectional.zero,
                                              //         onSelected: (value) {},
                                              //         style: const ButtonStyle(
                                              //           padding: WidgetStatePropertyAll(EdgeInsetsDirectional.zero),
                                              //           tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                              //           maximumSize: WidgetStatePropertyAll(Size.zero),
                                              //           visualDensity: VisualDensity(horizontal: 0, vertical: 0),
                                              //         ),
                                              //         itemBuilder:
                                              //             (context) => [
                                              //               PopupMenuItem(
                                              //                 padding: EdgeInsets.zero,
                                              //                 onTap: () async {},
                                              //                 value: "",
                                              //                 child: Padding(
                                              //                   padding: const EdgeInsets.all(0),
                                              //                   child: SizedBox(
                                              //                     width: 160,
                                              //                     child: DropDownWithSearchPopup(
                                              //                       key: UniqueKey(),
                                              //                       onChanged: (value, index, selectedId, name) {
                                              //                         print("hello");
                                              //
                                              //                         controller.medicationValue.value = name;
                                              //                         Get.back();
                                              //                         controller.updateMedicalView(selectedId);
                                              //                       },
                                              //                       list: controller.globalController.selectedMedicalModel.value,
                                              //                       receiveParam: (String value) {},
                                              //                       selectedId: 1,
                                              //                     ),
                                              //                   ),
                                              //                 ),
                                              //               ),
                                              //             ],
                                              //         child: SizedBox(
                                              //           width: 170,
                                              //           child: ContainerDropdownViewPopUp(
                                              //             receiveParam: (isExpand) {
                                              //               // isExpandedMedicalAssistant.value = isExpand;
                                              //             },
                                              //             name: controller.medicationValue.value,
                                              //           ),
                                              //         ),
                                              //       ),
                                              //     ),
                                              //   ],
                                              // ),
                                              Spacer(),

                                              Column(
                                                children: [
                                                  Text(textAlign: TextAlign.center, "Doctor", style: AppFonts.regular(12, AppColors.textBlack)),
                                                  const SizedBox(height: 6),
                                                  Text(textAlign: TextAlign.center, controller.doctorValue.value ?? "N/A", style: AppFonts.regular(14, AppColors.textGrey)),
                                                ],
                                              ),

                                              // Column(
                                              //   crossAxisAlignment:
                                              //       CrossAxisAlignment.start,
                                              //   children: [
                                              //     Text(
                                              //       textAlign: TextAlign.start,
                                              //       "Doctor",
                                              //       style: AppFonts.regular(
                                              //         12,
                                              //         AppColors.textBlack,
                                              //       ),
                                              //     ),
                                              //     const SizedBox(height: 6),
                                              //     PopupMenuButton<String>(
                                              //       offset: const Offset(0, 8),
                                              //       shape: RoundedRectangleBorder(
                                              //         borderRadius:
                                              //             BorderRadius.circular(
                                              //               6,
                                              //             ),
                                              //       ),
                                              //       color: AppColors.white,
                                              //       position:
                                              //           PopupMenuPosition.under,
                                              //       padding:
                                              //           EdgeInsetsDirectional
                                              //               .zero,
                                              //       menuPadding:
                                              //           EdgeInsetsDirectional
                                              //               .zero,
                                              //       onSelected: (value) {},
                                              //       style: const ButtonStyle(
                                              //         padding:
                                              //             WidgetStatePropertyAll(
                                              //               EdgeInsetsDirectional
                                              //                   .zero,
                                              //             ),
                                              //         tapTargetSize:
                                              //             MaterialTapTargetSize
                                              //                 .shrinkWrap,
                                              //         maximumSize:
                                              //             WidgetStatePropertyAll(
                                              //               Size.zero,
                                              //             ),
                                              //         visualDensity:
                                              //             VisualDensity(
                                              //               horizontal: 0,
                                              //               vertical: 0,
                                              //             ),
                                              //       ),
                                              //       itemBuilder:
                                              //           (context) => [
                                              //             PopupMenuItem(
                                              //               padding:
                                              //                   EdgeInsets.zero,
                                              //               onTap: () async {},
                                              //               value: "",
                                              //               child: Padding(
                                              //                 padding:
                                              //                     const EdgeInsets.all(
                                              //                       0,
                                              //                     ),
                                              //                 child: SizedBox(
                                              //                   width: 160,
                                              //                   child: DropDownWithSearchPopup(
                                              //                     key:
                                              //                         UniqueKey(),
                                              //                     onChanged: (
                                              //                       value,
                                              //                       index,
                                              //                       selectedId,
                                              //                       name,
                                              //                     ) {
                                              //                       print(
                                              //                         "print the doctor view ",
                                              //                       );
                                              //
                                              //                       controller
                                              //                           .doctorValue
                                              //                           .value = name;
                                              //                       Get.back();
                                              //                       controller
                                              //                           .updateDoctorView(
                                              //                             selectedId,
                                              //                           );
                                              //                     },
                                              //                     list:
                                              //                         controller
                                              //                             .globalController
                                              //                             .selectedDoctorModel
                                              //                             .value,
                                              //                     receiveParam:
                                              //                         (
                                              //                           String
                                              //                           value,
                                              //                         ) {},
                                              //                     selectedId: 1,
                                              //                   ),
                                              //                 ),
                                              //               ),
                                              //             ),
                                              //           ],
                                              //       child: SizedBox(
                                              //         width: 170,
                                              //         child: ContainerDropdownViewPopUp(
                                              //           receiveParam: (
                                              //             isExpand,
                                              //           ) {
                                              //             // isExpandedMedicalAssistant.value = isExpand;
                                              //           },
                                              //           name:
                                              //               controller
                                              //                   .doctorValue
                                              //                   .value,
                                              //         ),
                                              //       ),
                                              //     ),
                                              //   ],
                                              // ),
                                              const SizedBox(width: 20),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(height: 20),
                                      ],
                                    ),
                                  );
                                }),
                                const SizedBox(height: 10),
                                Container(
                                  width: double.infinity,
                                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: AppColors.backgroundWhite),
                                  child: Obx(() {
                                    return Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: AppColors.white),
                                      height: 45,
                                      child: SingleChildScrollView(
                                        physics: const BouncingScrollPhysics(),
                                        scrollDirection: Axis.horizontal,
                                        child: Row(
                                          children: [
                                            IntrinsicWidth(
                                              child: CustomAnimatedButton(
                                                onPressed: () {
                                                  // controller.closeAllProcedureDiagnosisPopover();
                                                  // controller.resetImpressionAndPlanList();
                                                  controller.resetImpressionAndPlanList();
                                                  controller.tabIndex.value = 0;
                                                },
                                                isDoctorView: true,
                                                text: " Power View ",
                                                isOutline: true,
                                                paddingText: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                                                fontSize: 14,
                                                enabledTextColor: controller.tabIndex.value == 0 ? AppColors.backgroundPurple : AppColors.textGrey,
                                                enabledColor: controller.tabIndex.value == 0 ? AppColors.buttonPurpleLight : AppColors.clear,
                                                outLineEnabledColor: AppColors.textGrey,
                                                outlineColor: controller.tabIndex.value == 0 ? AppColors.backgroundPurple : AppColors.clear,
                                              ),
                                            ),
                                            IntrinsicWidth(
                                              child: CustomAnimatedButton(
                                                onPressed: () async {
                                                  // controller.closeAllProcedureDiagnosisPopover();
                                                  // controller.resetImpressionAndPlanList();

                                                  controller.resetImpressionAndPlanList();
                                                  await controller.closeOnlyDoctorviewPopover();

                                                  Future.delayed(const Duration(milliseconds: 200), () {
                                                    controller.tabIndex.value = 3;
                                                  });
                                                },
                                                text: " Full Note ",
                                                isOutline: true,
                                                paddingText: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                                                fontSize: 14,
                                                enabledTextColor: controller.tabIndex.value == 3 ? AppColors.backgroundPurple : AppColors.textGrey,
                                                enabledColor: controller.tabIndex.value == 3 ? AppColors.buttonPurpleLight : AppColors.clear,
                                                outLineEnabledColor: AppColors.textGrey,
                                                outlineColor: controller.tabIndex.value == 3 ? AppColors.backgroundPurple : AppColors.clear,
                                              ),
                                            ),
                                            IntrinsicWidth(
                                              child: CustomAnimatedButton(
                                                onPressed: () async {
                                                  // controller.closeAllProcedureDiagnosisPopover();

                                                  controller.resetImpressionAndPlanList();
                                                  await controller.closeOnlyDoctorviewPopover();

                                                  Future.delayed(const Duration(milliseconds: 200), () {
                                                    controller.tabIndex.value = 2;
                                                  });
                                                },
                                                text: " Patient Note ",
                                                isOutline: true,
                                                paddingText: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                                                fontSize: 14,
                                                enabledTextColor: controller.tabIndex.value == 2 ? AppColors.backgroundPurple : AppColors.textGrey,
                                                enabledColor: controller.tabIndex.value == 2 ? AppColors.buttonPurpleLight : AppColors.clear,
                                                outLineEnabledColor: AppColors.textGrey,
                                                outlineColor: controller.tabIndex.value == 2 ? AppColors.backgroundPurple : AppColors.clear,
                                              ),
                                            ),
                                            IntrinsicWidth(
                                              child: CustomAnimatedButton(
                                                onPressed: () async {
                                                  // controller.closeAllProcedureDiagnosisPopover();

                                                  controller.resetImpressionAndPlanList();

                                                  controller.closeOnlyDoctorviewPopover();

                                                  Future.delayed(const Duration(milliseconds: 200), () {
                                                    controller.tabIndex.value = 1;
                                                  });
                                                },
                                                text: " Full Transcript ",
                                                isOutline: true,
                                                paddingText: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                                                fontSize: 14,
                                                enabledTextColor: controller.tabIndex.value == 1 ? AppColors.backgroundPurple : AppColors.textGrey,
                                                enabledColor: controller.tabIndex.value == 1 ? AppColors.buttonPurpleLight : AppColors.clear,
                                                outLineEnabledColor: AppColors.textGrey,
                                                outlineColor: controller.tabIndex.value == 1 ? AppColors.backgroundPurple : AppColors.clear,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  }),
                                ),
                                const SizedBox(height: 10),
                                Container(
                                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: AppColors.backgroundWhite),
                                  child: Obx(() {
                                    return Column(
                                      children: [
                                        const SizedBox(height: 20),
                                        if (controller.tabIndex.value == 0) ...[DoctorView(controller: controller)],
                                        if (controller.tabIndex.value == 1) ...[FullTranscriptView(controller: controller)],
                                        if (controller.tabIndex.value == 2) ...[PatientView(controller: controller)],
                                        if (controller.tabIndex.value == 3) ...[FullNoteView(controller: controller)],
                                        if (controller.tabIndex.value == 6) ...[VisitDataView(controller: controller)],
                                        const SizedBox(height: 20),
                                      ],
                                    );
                                  }),
                                ),
                                const SizedBox(height: 20),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                if (!controller.keyboardController.isKeyboardOpen.value) ...[
                  Container(
                    color: AppColors.ScreenBackGround1,
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    child: Container(
                      // color: AppColors.backgroundWhite,
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: AppColors.backgroundWhite),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                      child: Obx(() {
                        return Row(
                          spacing: 15,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            if (controller.isSignatureDone.value) ...[
                              Expanded(
                                child: GestureDetector(
                                  onTap: () {},
                                  child: Column(
                                    children: [
                                      Container(
                                        height: 95,
                                        decoration: BoxDecoration(border: Border.all(color: AppColors.backgroundPurple), color: AppColors.backgroundPurple, borderRadius: BorderRadius.circular(8)),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Column(
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                SvgPicture.asset(ImagePath.signature, height: 30, width: 30),
                                                const SizedBox(height: 10),
                                                Text(textAlign: TextAlign.center, "Digitally Signed by ${controller.patientData.value?.responseData?.doctorName}", style: AppFonts.medium(16, AppColors.textWhite)),
                                                Text(textAlign: TextAlign.center, formatDateTime(firstDate: controller.patientData.value?.responseData?.visitDate ?? "", secondDate: controller.patientData.value?.responseData?.visitTime ?? ""), style: AppFonts.medium(16, AppColors.textWhite)),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                      const SizedBox(height: 10),
                                      Text(textAlign: TextAlign.center, "Amend Note", style: AppFonts.medium(15, AppColors.textGrey).copyWith(decoration: TextDecoration.underline)),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                            if (controller.isSignatureDone.value == false) ...[
                              Expanded(
                                child: GestureDetector(
                                  onTap: () {},
                                  child: Container(
                                    height: 81,
                                    decoration: BoxDecoration(border: Border.all(color: AppColors.textGrey.withValues(alpha: 0.5)), color: AppColors.backgroundLightGrey, borderRadius: BorderRadius.circular(8)),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [SvgPicture.asset(ImagePath.add_photo, height: 30, width: 30), const SizedBox(height: 10), Text(textAlign: TextAlign.center, "Add Photo or Document", style: AppFonts.medium(16, AppColors.textBlack))],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              if (controller.patientData.value?.responseData?.visitStatus == "Pending") ...[
                                Expanded(
                                  child: GestureDetector(
                                    onTap: () async {
                                      showDialog(
                                        context: context,
                                        barrierDismissible: true,
                                        builder: (BuildContext context) {
                                          return ConfirmFinalizeDialog(
                                            onDelete: () {
                                              controller.changeStatus();
                                            },
                                          );
                                        },
                                      );
                                    },
                                    child: Container(
                                      height: 81,
                                      decoration: BoxDecoration(border: Border.all(color: AppColors.backgroundPurple), color: AppColors.backgroundPurple, borderRadius: BorderRadius.circular(8)),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Column(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [SvgPicture.asset(ImagePath.signature, height: 30, width: 30), const SizedBox(height: 10), Text(textAlign: TextAlign.center, "Sign and Finalize", style: AppFonts.medium(16, AppColors.textWhite))],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ],
                        );
                      }),
                    ),
                  ),
                ],
              ],
            );
          }),
        ),
      ),
      globalKey: _key,
    );
  }
}
