import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:subqdocs/app/modules/patient_info/views/EditableViews/skin_history_editable_view.dart';

import '../../../../utils/app_colors.dart';
import '../../../../utils/app_fonts.dart';
import '../../../../utils/imagepath.dart';
import '../controllers/patient_info_controller.dart';
import 'EditableViews/CommonContainer.dart';
import 'EditableViews/alergies_editable.dart';
import 'EditableViews/cancer_history_editable_view.dart';
import 'EditableViews/chief_complaint.dart';
import 'EditableViews/exam_editable.dart';
import 'EditableViews/hpi_editable_view.dart';
import 'EditableViews/medication_editable.dart';
import 'EditableViews/review_of_systems.dart';
import 'EditableViews/social_history_editable_view.dart';
import 'impression_and_plan.dart';

class FullNoteView extends StatelessWidget {
  FullNoteView({super.key, required this.controller});

  PatientInfoController controller;

  // PatientInfoController controller = Get.find<PatientInfoController>(tag: Get.arguments["unique_tag"]);

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return Column(
        children: [
          if ((controller.isFullNoteLoading.value || controller.patientFullNoteModel.value?.responseData == null)) ...[
            Center(child: Column(children: [Lottie.asset('assets/lottie/loader.json', width: 200, height: 200, fit: BoxFit.fill), Text(controller.isFullNoteLoadText.value)])),
          ] else ...[
            if (controller.patientFullNoteModel.value?.responseData?.status == "Failure") ...[
              Center(child: Padding(
                padding: const EdgeInsets.all(20),
                child: Text(controller.patientFullNoteModel.value?.responseData?.message ?? "No data found", textAlign: TextAlign.start , style:  AppFonts.medium(14, AppColors.textBlack),),
              )),
            ] else ...[

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    Text(textAlign: TextAlign.left, "Patient Medical Record", style: AppFonts.medium(20, AppColors.textBlack)),
                    Spacer(),

                    GestureDetector(
                      onTap: () {
                        controller.copyAllSection();
                      },
                      child: Icon(Icons.copy, color: Colors.grey),
                    ),

                    SizedBox(width: 10),
                    GestureDetector(
                      onTap: () {
                        controller.loadFullNotePDF(controller.visitId);
                      },
                      child: SvgPicture.asset(ImagePath.download_pdf, width: 30, height: 30),
                    ),

                  ],
                ),
              ),

                SizedBox(height: 20,),
              Divider(height: 1, color: AppColors.textGrey.withValues(alpha: 0.2)),
              SizedBox(height: 16,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  spacing: 10,
                  children: [
                    Container(
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(width: 1, color: AppColors.borderTable)),

                      child: Theme(
                        // Required for ReorderableListView
                        data: ThemeData(splashColor: Colors.transparent, highlightColor: Colors.transparent),
                        child: ExpansionTile(
                          enabled: true,
                          initiallyExpanded: true,
                          visualDensity: VisualDensity(vertical: -4),
                          tilePadding: EdgeInsets.symmetric(horizontal: 16 , vertical: 10),
                          trailing: SvgPicture.asset(ImagePath.expanseTileIcon),
                          childrenPadding: EdgeInsets.all(0),
                          collapsedShape: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(8)),
                          shape: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(8)),
                          backgroundColor: AppColors.white,
                          showTrailingIcon: true,
                          collapsedBackgroundColor:AppColors.white,
                          title:Row(children: [Text("Patient History" , style: AppFonts.medium(16, AppColors.black),)],),
                          children: [
                            Column(
                              children: [

                                Divider(height: 1, color: AppColors.borderTable),
                                SizedBox(height: 12,),
                                Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 10),
                                  child: Column(
                                    spacing: 10,
                                    children: [

                                      CommonContainer(title: "Cancer History", child: CancerHistoryEditableView(controller: controller)),
                                      CommonContainer(title: "Skin History", child: skinHistoryEditableView(controller: controller)),
                                      CommonContainer(title: "Social History", child: SocialHistoryEditableView(controller: controller)),
                                      CommonContainer(title: "Medications", child: MedicationEditable(controller: controller)),
                                      CommonContainer(title: "Allergies", child: AlergiesEditable(controller: controller)),
                                      SizedBox(height: 12,),
                                    ],
                                  ),
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                    CommonContainer(title: "Chief Complaint", child: ChiefComplaint(controller: controller)),
                    CommonContainer(title: "HPI", child: HpiEditableView(controller: controller)),
                    CommonContainer(title: "Review of Systems", child: ReviewOfSystemsEditableView(controller: controller)),
                    CommonContainer(title: "Exam", child: ExamEditable(controller: controller)),
                    ImpressionAndPlanPatientView(controller: controller),
                  ],
                ),
              ),
              SizedBox(height: 20),
            ],
          ],
          // ],
        ],
      );
    });
  }
}
