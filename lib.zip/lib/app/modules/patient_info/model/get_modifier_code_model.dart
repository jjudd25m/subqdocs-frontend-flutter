class GetModifierCodeModel {
  GetModifierCodeResponseData? responseData;
  String? message;
  bool? toast;
  String? responseType;

  GetModifierCodeModel({this.responseData, this.message, this.toast, this.responseType});

  GetModifierCodeModel.fromJson(Map<String, dynamic> json) {
    responseData = json['responseData'] != null ? GetModifierCodeResponseData.fromJson(json['responseData']) : null;
    message = json['message'];
    toast = json['toast'];
    responseType = json['response_type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    if (this.responseData != null) {
      data['responseData'] = this.responseData!.toJson();
    }
    data['message'] = this.message;
    data['toast'] = this.toast;
    data['response_type'] = this.responseType;
    return data;
  }
}

class GetModifierCodeResponseData {
  List<GetModifierCodeResponseDataData>? data;
  String? page;
  String? limit;
  int? totalCount;
  int? totalPage;

  GetModifierCodeResponseData({this.data, this.page, this.limit, this.totalCount, this.totalPage});

  GetModifierCodeResponseData.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <GetModifierCodeResponseDataData>[];
      json['data'].forEach((v) {
        data!.add(GetModifierCodeResponseDataData.fromJson(v));
      });
    }
    page = json['page'];
    limit = json['limit'];
    totalCount = json['totalCount'];
    totalPage = json['totalPage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    data['page'] = this.page;
    data['limit'] = this.limit;
    data['totalCount'] = this.totalCount;
    data['totalPage'] = this.totalPage;
    return data;
  }
}

class GetModifierCodeResponseDataData {
  int? id;
  String? modifier;
  String? description;
  String? createdAt;
  String? updatedAt;
  Null? deletedAt;

  GetModifierCodeResponseDataData({this.id, this.modifier, this.description, this.createdAt, this.updatedAt, this.deletedAt});

  GetModifierCodeResponseDataData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    modifier = json['modifier'];
    description = json['description'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    deletedAt = json['deleted_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['id'] = this.id;
    data['modifier'] = this.modifier;
    data['description'] = this.description;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['deleted_at'] = this.deletedAt;
    return data;
  }
}
