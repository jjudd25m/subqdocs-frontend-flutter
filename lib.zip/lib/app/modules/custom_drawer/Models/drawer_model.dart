class DrawerItemModel {
  String? routePath;
  String? drawerItemTitle;
  String? drawerIconPath;
  bool? isSelected;

  DrawerItemModel({this.routePath, this.drawerItemTitle, this.drawerIconPath, this.isSelected = false});
}
