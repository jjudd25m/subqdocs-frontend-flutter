class LatestPatientId {
  ResponseData? responseData;
  String? message;
  bool? toast;
  String? responseType;

  LatestPatientId(
      {this.responseData, this.message, this.toast, this.responseType});

  LatestPatientId.fromJson(Map<String, dynamic> json) {
    responseData = json['responseData'] != null
        ? new ResponseData.fromJson(json['responseData'])
        : null;
    message = json['message'];
    toast = json['toast'];
    responseType = json['response_type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.responseData != null) {
      data['responseData'] = this.responseData!.toJson();
    }
    data['message'] = this.message;
    data['toast'] = this.toast;
    data['response_type'] = this.responseType;
    return data;
  }
}

class ResponseData {
  String? patientId;

  ResponseData({this.patientId});

  ResponseData.fromJson(Map<String, dynamic> json) {
    patientId = json['patientId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['patientId'] = this.patientId;
    return data;
  }
}
