import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:subqdocs/utils/app_colors.dart';
import 'package:subqdocs/utils/app_fonts.dart';
import 'package:subqdocs/utils/imagepath.dart';
import 'package:zoom_widget/zoom_widget.dart';

import '../../../../widget/custom_animated_button.dart';

class DeleteScheduleVisit extends StatelessWidget {
  final VoidCallback? onDelete;
  String? extension;

  DeleteScheduleVisit({required this.onDelete, this.extension});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      elevation: 16,
      child: Container(
        width: MediaQuery.of(context).size.width * 0.5,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              height: 50,
              width: double.infinity,
              decoration: BoxDecoration(
                color: AppColors.backgroundPurple,
                borderRadius: BorderRadius.only(topLeft: Radius.circular(12), topRight: Radius.circular(12)),
              ),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      "Cancel Visit",
                      style: AppFonts.medium(15, Colors.white),
                    ),
                    Spacer(),
                    GestureDetector(
                      onTap: () {
                        Get.back();
                      },
                      child: SvgPicture.asset(
                        ImagePath.logo_cross,
                        width: 20,
                        height: 20,
                        colorFilter: ColorFilter.mode(AppColors.backgroundWhite, BlendMode.srcIn),
                      ),
                    ),
                    SizedBox(width: 10)
                  ],
                ),
              ),
            ),
            Container(
                child: Column(
              children: [
                SizedBox(
                  height: 40,
                ),
                SvgPicture.asset(
                  ImagePath.delete_popup,
                  width: 70,
                  height: 70,
                ),
                SizedBox(height: 20),
                SizedBox(
                  width: 280,
                  child: Text(
                    textAlign: TextAlign.center,
                    "Are you sure you want to Cancel this visit?",
                    style: AppFonts.medium(17, AppColors.textBlack),
                  ),
                ),
                SizedBox(height: 20),
                Text(
                  "",
                  style: AppFonts.medium(15, AppColors.textGrey),
                ),
                SizedBox(height: 40),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    children: [
                      SizedBox(
                          width: 90,
                          height: 40,
                          child: CustomAnimatedButton(
                            onPressed: () {
                              navigator?.pop();
                            },
                            text: "Cancel",
                            isOutline: true,
                            enabledTextColor: AppColors.backgroundPurple,
                            enabledColor: AppColors.white,
                            outLineEnabledColor: AppColors.textGrey,
                            outlineColor: AppColors.backgroundPurple,
                          )),
                      Spacer(),
                      SizedBox(
                          width: 90,
                          height: 40,
                          child: CustomAnimatedButton(
                            onPressed: () {
                              Get.back();
                              onDelete!();
                            },
                            text: " Delete ",
                            isOutline: true,
                            enabledTextColor: AppColors.textWhite,
                            enabledColor: AppColors.buttonBackgroundred,
                            outLineEnabledColor: AppColors.textGrey,
                            outlineColor: AppColors.buttonBackgroundred,
                          ))
                    ],
                  ),
                )
              ],
            )),
            SizedBox(
              height: 20,
            )
          ],
        ),
      ),
    );
  }
}
