class AppConstants {
  //App related
  static String appName = "SubQDocs";
  static const int appVersion = 1;
}
