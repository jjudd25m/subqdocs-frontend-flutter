import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

class OrientationService extends GetxService {
  static OrientationService get to => Get.find();

  final orientation = Orientation.portrait.obs;

  @override
  void onInit() {
    super.onInit();
    _setInitialOrientation();
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
  }

  void _setInitialOrientation() {
    final mediaQuery = MediaQuery.of(Get.context!);
    orientation.value = mediaQuery.orientation;
  }

  void listenToOrientationChanges() {
    // This will be called whenever the orientation changes
    ever(orientation, (Orientation newOrientation) {
      print('Orientation changed to: $newOrientation');
      // You can add your custom logic here
    });
  }
}
